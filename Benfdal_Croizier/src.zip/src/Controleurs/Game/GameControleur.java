// Controleurs/Game/GameControleur.java
package Controleurs.Game;

import Controleurs.Menu.MenuControleur;
import Modeles.game.GameModel;
import Modeles.items.consumables.Consumable;
import Modeles.settings.SettingsModel;
import Modeles.characters.Hero;
import Modeles.items.weapons.Weapon;
import Vues.Menu.SplashMenu;
import Vues.game.ChoiceView;
import Vues.game.GameView;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.Parent;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;
import javafx.util.Duration;
import utils.TransitionUtils;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class GameControleur {
    private final Stage stage;
    private GameView vue;
    private GameModel model = null;
    private final Map<String, KeyCode> keyBindings = new HashMap<>();
    private final Map<String, Boolean> directionsActives = new HashMap<>();
    private Timeline mouvementLoop;
    private String currentAnimationDirection = null;
    private boolean isTransitioning = false;

    public GameControleur(Stage stage) {
        this.stage = stage;

        // Crée un Hero avant de créer GameModel
        this.model = new GameModel(); // Crée d'abord un modèle vide

        Hero hero = new Hero("HeroName", Weapon.parseFromString("Sword"), model); // Passe le modèle
        this.model.setHero(hero); // Associe le héros au modèle
        this.vue = new GameView(model); // Vue peut maintenant utiliser model sans null

        // Chargement des touches personnalisées
        SettingsModel.load().getTouches().forEach((action, keyName) -> {
            try {
                keyBindings.put(action, KeyCode.valueOf(keyName.toUpperCase(Locale.ROOT)));
            } catch (IllegalArgumentException e) {
                System.err.println("❌ Touche invalide : " + keyName);
            }
        });

        // Initialisation des directions
        directionsActives.put("up", false);
        directionsActives.put("down", false);
        directionsActives.put("left", false);
        directionsActives.put("right", false);

        vue.setPlayerPosition(model.getPlayerX(), model.getPlayerY());

        // Gestion clavier pour le mouvement
        vue.setOnKeyPressed(event -> {
            String dir = getDirectionFromKey(event.getCode());
            if (dir != null) {
                directionsActives.put(dir, true);
                if (mouvementLoop == null) startMouvementLoop();
            }
        });
        vue.setOnKeyReleased(event -> {
            String dir = getDirectionFromKey(event.getCode());
            if (dir != null) {
                directionsActives.put(dir, false);
                if (directionsActives.values().stream().noneMatch(b -> b)) {
                    stopMouvementLoop();
                }
            }
        });
    }

    private String getDirectionFromKey(KeyCode key) {
        if (key == keyBindings.get("moveUp"))    return "up";
        if (key == keyBindings.get("moveDown"))  return "down";
        if (key == keyBindings.get("moveLeft"))  return "left";
        if (key == keyBindings.get("moveRight")) return "right";
        return null;
    }

    public Parent getVue() {
        return vue;
    }

    public void updateSelection(int selectedDoor) {
        System.out.println("🚪 Porte sélectionnée : " + selectedDoor);
    }

    private void startMouvementLoop() {
        mouvementLoop = new Timeline(new KeyFrame(Duration.millis(40), e -> {
            double futurX = model.getPlayerX();
            double futurY = model.getPlayerY();
            double pas = model.getHero().getSpeed() / 10.0; // ou / 8.0, à ajuster selon l’équilibre

            boolean up    = directionsActives.get("up");
            boolean down  = directionsActives.get("down");
            boolean left  = directionsActives.get("left");
            boolean right = directionsActives.get("right");

            if (up)    futurY -= pas;
            if (down)  futurY += pas;
            if (left)  futurX -= pas;
            if (right) futurX += pas;

            if (model.peutAller(futurX, futurY)) {
                model.setPlayerPosition(futurX, futurY);
                vue.setPlayerPosition(futurX, futurY);
            }

            // Animation en fonction de la direction
            String nouvelleDirection = up ? "up" : down ? "down" : null;
            if (!sameDirection(nouvelleDirection, currentAnimationDirection)) {
                stopCurrentAnimation();
                if ("up".equals(nouvelleDirection))   vue.startWalkUpAnimation();
                else if ("down".equals(nouvelleDirection)) vue.startWalkDownAnimation();
                currentAnimationDirection = nouvelleDirection;
            }

            // Passage à l'étage suivant
            if (!isTransitioning && model.checkNextFloor()) {
                isTransitioning = true; // bloque les prochaines détections
                model.changerEtage(model.getLocationActuelle().getFloorLevel() + 1, "Nouvelle zone !");
                showChoiceView();
            }

        }));
        mouvementLoop.setCycleCount(Animation.INDEFINITE);
        mouvementLoop.play();
    }

    private void showChoiceView() {
        ChoiceView choiceView = new ChoiceView(stage, this);
        TransitionUtils.fadeToScene(stage, choiceView.getVue());
    }

    public void updateFloor() {
        model.setPlayerPosition(13 * model.getTailleCase(), 13 * model.getTailleCase());
        Hero hero = model.getHero();
        hero.resetStats();
        hero.reapplyBonuses();

        isTransitioning = false; // ✅ autorise à nouveau les transitions
        vue.setPlayerPosition(model.getPlayerX(), model.getPlayerY());
        vue.updateFloorLabel();
        TransitionUtils.fadeToScene(stage, vue);
    }


    private void stopMouvementLoop() {
        if (mouvementLoop != null) {
            mouvementLoop.stop();
            mouvementLoop = null;
        }
        stopCurrentAnimation();
        currentAnimationDirection = null;
    }

    private boolean sameDirection(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    private void stopCurrentAnimation() {
        if ("up".equals(currentAnimationDirection))   vue.stopWalkUpAnimation();
        else if ("down".equals(currentAnimationDirection)) vue.stopWalkDownAnimation();
    }



    public void quitterJeu() {
        MenuControleur mc = new MenuControleur(stage);
        mc.jouerMusiqueMenu();
        SplashMenu menu = new SplashMenu(mc);
        mc.creerVueAvecFond(menu);
        TransitionUtils.fadeToScene(stage, mc.creerVueAvecFond(menu));
    }

    public GameModel getModel() {
        return model;
    }


}
